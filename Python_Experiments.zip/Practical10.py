def linear_search(arr, target):
    for i in range(len(arr)):
        if arr[i] == target:
            return i
    return -1

# call the function
# input the array
numbers = [10, 20, 30, 40, 50]
# element to be searched
target = 30
result = linear_search(numbers, target)
if result != -1:
    print("Element found at index:", result)
else:
    print("Element not found")

n = int(input("Enter the number of elements: "))
arr = []

for i in range(n):
    num = int(input(f"Enter element {i + 1}: "))
    arr.append(num)
target = int(input("Enter the element to search: "))
found = False
for i in range(n):
    if arr[i] == target:
        print("Element found at position:", i)
        found = True
        break
if not found:
    print("Element not found")


n = int(input("Enter the number of elements: "))
arr = []
for i in range(n):
    num = int(input(f"Enter element {i + 1}: "))
    arr.append(num)
# Sort the list
arr.sort()
print("Sorted list:", arr)
target = int(input("Enter the element to search: "))
low = 0
high = n - 1
found = False
while low <= high:
    mid = (low + high) // 2
    if arr[mid] == target:
        print("Element found at position:", mid)
        found = True
        break
    elif target < arr[mid]:
        high = mid - 1
    else:
        low = mid + 1
if not found:
    print("Element not found")