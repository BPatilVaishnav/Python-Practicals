# EXPERIMENT 7: Python Practical Programs
# Modified examples; each file is self-contained.

# EXPERIMENT 7: NumPy Arrays and Operations
import numpy as np

# Creating one-dimensional arrays
a = np.array([2, 4, 6])
print("Type:", type(a))
print("Shape:", a.shape)
print("Elements:", a[0], a[1], a[2])
a[0] = 8
print("Updated array:", a)

# Creating arrays of zeros, ones, range and equally spaced values
print("Zeros array:\n", np.zeros((2, 3)))
print("Ones array:\n", np.ones((3, 2)))
print("Range array:", np.arange(1, 10, 2))
print("Linear array:", np.linspace(0, 1, 5))

# Creating and accessing a two-dimensional array
b = np.array([[2, 4, 6], [8, 10, 12]])
print("Shape:", b.shape)
print("Selected elements:", b[0, 0], b[1, 2])
print("2D array:\n", b)
print("Random array:\n", np.random.rand(2, 2))

# Mathematical operations on arrays
arr1 = np.array([[4, 8], [2, 6]], dtype=np.float64)
arr2 = np.array([[3, 5], [7, 1]], dtype=np.float64)
print("Array 1:\n", arr1)
print("Array 2:\n", arr2)
print("Addition:\n", np.add(arr1, arr2))
print("Sum of array 1:", np.sum(arr1))
print("Square root:\n", np.sqrt(arr1))
print("Transpose:\n", arr1.T)

# Arithmetic operators
x = np.array([[1, 3], [5, 7]], dtype=np.float64)
y = np.array([[2, 4], [6, 8]], dtype=np.float64)
print("Addition:\n", x + y)
print("Subtraction:\n", x - y)
print("Multiplication:\n", x * y)
print("Division:\n", x / y)
print("Square root of x:\n", np.sqrt(x))

# Dot product
v = np.array([2, 3])
w = np.array([4, 5])
print("Vector dot product:", v.dot(w))
print("Element-wise product:", np.multiply(v, w))
print("Matrix-vector product:\n", x.dot(v))

# Statistical and indexing operations
values = np.array([2, 4, 6, 8])
print("Mean:", np.mean(values))
print("Maximum:", np.max(values))
print("Minimum:", np.min(values))
print("Element at index 2:", values[2])
print("Slice:", values[1:3])
print("Sorted array:", np.sort(np.array([5, 1, 4, 2])))
print("Indices greater than 5:", np.where(values > 5))
