# EXPERIMENT 9: Python Practical Programs
# Modified examples; each file is self-contained.

import array as arr

a = arr.array('i', [2, 4, 6])

for i in range(0, 3):
    print(a[i], end=" ")



a = arr.array('i', [2, 4, 6])
print(*a)

a.insert(1, 4)
print(*a)


import array

a = array.array('i', [2, 4, 6, 2, 8])

# remove first occurence of 1
a.remove(1)
print(a)

# remove item at index 2
a.pop(2)
print(a)



a = array.array('i', [2, 4, 6, 2, 4, 8])

# update item at index 2
a[2] = 6
print(a)

# update item at index 4
a[4] = 8
print(a)



a = arr.array('i', [2, 4, 6, 8, 10, 12])

print(a[0])
print(a[3])

b = arr.array('d', [2.5, 3.2, 3.3])

print(b[1])
print(b[2])



a = array.array('i', [2, 4, 6, 2, 4, 8])

# index of 1st occurrence of 2
print(a.index(2))

# index of 1st occurrence of 1
print(a.index(1))



a = array.array('i', [1, 2, 3, 4, 2, 5, 2])

count = a.count(2)
print(count)



a = array.array('i', [3, 6, 9, 12, 15])

a.reverse()
print(*a)



a = arr.array('i', [3, 6, 9, 12, 15])

a.extend([6, 7, 8, 9, 10])
print(a)


def bubbleSort(arr):
    n = len(arr)

    for i in range(n):
        swapped = False

        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True

        if not swapped:
            break


arr = [64, 34, 25, 12, 22, 11, 90]

bubbleSort(arr)

print(arr)


def insertionSort(arr):
    n = len(arr)

    if n <= 1:
        return

    for i in range(1, n):
        key = arr[i]
        j = i - 1

        while j >= 0 and key < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1

        arr[j + 1] = key


arr = [12, 11, 13, 5, -1]

insertionSort(arr)

print(arr)