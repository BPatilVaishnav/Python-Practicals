stack = ["Plate 1", "Plate 2", "Plate 3"]
# Add new plates/PUSH to the top of the stack
stack.append("Plate 4")
stack.append("Plate 5")
print(stack)
# Remove the topmost plate/POP
print("Removed:", stack.pop())
print(stack)
# Remove the topmost plate again
print("Removed:", stack.pop())
print(stack)

queue = ["Person 1", "Person 2", "Person 3"]
queue.append("Person 4")
queue.append("Person 5")
print(queue)
# Removes the first person
print(queue.pop(0))
print(queue)
# Removes the first person
print(queue.pop(0))
print(queue)

from collections import deque
queue = deque(["Person 1", "Person 2", "Person 3", "Person 4"])
print(queue)
queue.append("Person 5")
print(queue)
queue.append("Person 6")
print(queue)
print(queue.popleft())
print(queue.popleft())
print(queue)