# EXPERIMENT 6: Python Practical Programs
# Modified examples; each file is self-contained.

# EXPERIMENT 6: Python Modules and Packages
# This version is self-contained, so it can be copied and run as one file.

# Module 1: prime number and factorial functions
def check_prime(number):
    if number < 2:
        return "Not a prime number"
    for divisor in range(2, int(number ** 0.5) + 1):
        if number % divisor == 0:
            return "Not a prime number"
    return "Prime number"

def calculate_factorial(number):
    if number < 0:
        return "Factorial is not defined for negative numbers"
    result = 1
    for value in range(1, number + 1):
        result *= value
    return result

number = int(input("Enter a number: "))
print(check_prime(number))
print("Factorial:", calculate_factorial(number))

# Module 2: arithmetic operations
def add(a, b):
    return a + b

def multiply(a, b):
    return a * b

first, second = map(int, input("Enter two numbers separated by space: ").split())
print("Addition:", add(first, second))
print("Multiplication:", multiply(first, second))

# Importing a built-in module
import math
print("Square root using math:", math.sqrt(36))

# Importing one function from a module
from math import sqrt
print("Square root using sqrt:", sqrt(49))
