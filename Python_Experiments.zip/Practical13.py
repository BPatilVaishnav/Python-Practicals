# Create a node
class Node:
	def __init__(self, data):
		self.data = data
		self.left = None
		self.right = None
# Create the root node
root = Node(8)
# Create child nodes
root.left = Node(3)
root.right = Node(10)

root.left.left = Node(1)
root.left.right = Node(6)
root.left.right.left = Node(4)
root.left.right.right = Node(7)
root.right.right = Node(14)
root.right.right.left = Node(13)
# Display the tree
print("Root:", root.data)
print("Left child:", root.left.data)
print("Right child:", root.right.data)
print("Left child of 3 :", root.left.left.data)
print("Right child of 3:", root.left.right.data)
print("Left child of 6:", root.left.right.left.data)
print("Right child of 6:", root.left.right.right.data)
print("Right child of 10:", root.right.right.data)
print("Left side of 14:" ,root.right.right.left.data)