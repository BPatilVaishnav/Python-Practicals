class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

# Create nodes
node1 = Node(15)
node2 = Node(3)
node3 = Node(17)
node4 = Node(90)
node5 = Node(40)
node6 = Node(70)

# Link nodes
node5.next = node1
node1.next = node2
node2.next = node3
node3.next = node4
node4.next = node6
node6.next = None

head = node5  # Head points to the first node

# Traverse and print the linked list
current = head
while current is not None:
    print(current.data, end=" -> ")
    current = current.next
print("None")

# Second linked list example
nodeA = Node(10)
nodeB = Node(20)
nodeC = Node(30)
nodeD = Node(40)

# Second linked list example
nodeA = Node(10)
nodeB = Node(20)
nodeC = Node(30)
nodeD = Node(40)

# Link the nodes
nodeA.next = nodeB
nodeB.next = nodeC
nodeC.next = nodeD

# Traverse the linked list
current = nodeA
while current is not None:
    print(current.data, end=" -> ")
    current = current.next
print("None")

class LinkedList:
    def __init__(self):
        self.head = None

    def insert_beginning(self, data):
        new_node = Node(data)
        new_node.next = self.head
        self.head = new_node

    def insert_end(self, data):
        new_node = Node(data)
        if self.head is None:
            self.head = new_node
            return

        temp = self.head
        while temp.next is not None:
            temp = temp.next
        temp.next = new_node

    def insert_position(self, data, position):
        if position < 1:
            print("Invalid position!")
            return

        new_node = Node(data)
        if position == 1:
            new_node.next = self.head
            self.head = new_node
            return

        temp = self.head
        for _ in range(1, position - 1):
            if temp is None:
                print("Invalid position!")
                return
            temp = temp.next

        if temp is None:
            print("Invalid position!")
            return

        new_node.next = temp.next
        temp.next = new_node

    def display(self):
        temp = self.head
        while temp is not None:
            print(temp.data, end=" -> ")
            temp = temp.next
        print("None")


# Main program
ll = LinkedList()
print("Original linked list:")
ll.display()
ll.insert_beginning(5)
print("After insertion at beginning:")
ll.display()
ll.insert_end(10)
ll.insert_end(20)
ll.insert_end(30)
ll.insert_end(40)
print("After insertion at end:")
ll.display()
ll.insert_position(25, 4)
print("After inserting 25 at position 4:")
ll.display()
class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


class LinkedList:
    def __init__(self):
        self.head = None

    def insert_end(self, data):
        new_node = Node(data)
        if self.head is None:
            self.head = new_node
            return

        temp = self.head
        while temp.next is not None:
            temp = temp.next
        temp.next = new_node

    def delete_beginning(self):
        if self.head is None:
            print("List is empty!")
            return
        self.head = self.head.next

    def delete_end(self):
        if self.head is None:
            print("List is empty!")
            return
        if self.head.next is None:
            self.head = None
            return

        temp = self.head
        while temp.next.next is not None:
            temp = temp.next
        temp.next = None

    def delete_position(self, position):
        if position < 1:
            print("Invalid position!")
            return
        if self.head is None:
            print("List is empty!")
            return
        if position == 1:
            self.head = self.head.next
            return

        temp = self.head
        for _ in range(1, position - 1):
            if temp.next is None:
                print("Invalid position!")
                return
            temp = temp.next
        if temp.next is None:
            print("Invalid position!")
            return
        temp.next = temp.next.next

    def display(self):
        temp = self.head
        while temp is not None:
            print(temp.data, end=" -> ")
            temp = temp.next
        print("None")


# Main program
ll = LinkedList()
for value in (10, 20, 30, 40, 50):
    ll.insert_end(value)
print("Original linked list:")
ll.display()
ll.delete_beginning()
print("After deleting from beginning:")
ll.display()
ll.delete_end()
print("After deleting from end:")
ll.display()
ll.delete_position(2)
print("After deleting node at position 2:")
ll.display()


class DoublyLinkedNode:
    def __init__(self, data):
        # To store the value or data.
        self.data = data
        # References to the previous and next nodes.
        self.prev = None
        self.next = None


# Create 4 nodes
node1 = DoublyLinkedNode(10)
node2 = DoublyLinkedNode(20)
node3 = DoublyLinkedNode(30)
node4 = DoublyLinkedNode(40)

# Link the nodes
node1.next = node2
node2.prev = node1
node2.next = node3
node3.prev = node2
node3.next = node4
node4.prev = node3

# Traverse forward
print("Forward traversal:")
current = node1
while current:
    print(current.data, end=" <-> ")
    current = current.next
print("None")

# Traverse backward
print("\nBackward traversal:")
current = node4
while current:
    print(current.data, end=" <-> ")
    current = current.prev
print("None")

class Node:
    def __init__(self, data):
        self.data = data
        self.prev = None
        self.next = None

class DoublyLinkedList:
    def __init__(self):
        self.head = None

    # Insert a node at the end
    def insert_at_end(self, data):
        new_node = Node(data)
        if self.head is None:
            self.head = new_node
            return
        current = self.head
        while current.next:
            current = current.next
        current.next = new_node
        new_node.prev = current

    # Forward traversal
    def traverse_forward(self):
        current = self.head
        while current:
            print(current.data, end=" <-> ")
            current = current.next
        print("None")

# Create a doubly linked list
dll = DoublyLinkedList()
# Insert elements at the end
dll.insert_at_end(10)
dll.insert_at_end(20)
dll.insert_at_end(30)
dll.insert_at_end(40)
# Forward traversal
dll.traverse_forward()

class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class CircularLinkedList:
    def __init__(self):
        self.head = None

    # Insert a node at the end
    def insert_at_end(self, data):
        new_node = Node(data)
        if self.head is None:
            self.head = new_node
            new_node.next = self.head
            return
        current = self.head
        while current.next != self.head:
            current = current.next
        current.next = new_node
        new_node.next = self.head

    # Traverse from the head node
    def traverse(self):
        if self.head is None:
            print("List is empty")
            return
        current = self.head
        while True:
            print(current.data, end=" -> ")
            current = current.next
            if current == self.head:
                break
        print("(Back to Head)")

# Create a circular linked list
cll = CircularLinkedList()
# Insert nodes
cll.insert_at_end(10)
cll.insert_at_end(20)
cll.insert_at_end(30)
cll.insert_at_end(40)
# Traverse the list
cll.traverse()